package com.example.afg.gradingsystem;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.makeText;


/**
 * A simple {@link Fragment} subclass.
 */
public class CourseFragment extends Fragment {

    DataBaseHelper myDb;
    EditText editText1,editText2,editText3,editText4,editText5;
    View view;
    Button btn;


    public CourseFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_course, container, false);
        editText1 = (EditText) view.findViewById(R.id.courseN);
        editText2 = (EditText) view.findViewById(R.id.courseC);
        editText3 = (EditText) view.findViewById(R.id.courseM);
        editText4 = (EditText) view.findViewById(R.id.courseP);
        editText5 = (EditText) view.findViewById(R.id.courseT);
        btn = (Button) view.findViewById(R.id.addCourse);
        myDb = new DataBaseHelper(getContext());

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              boolean isInserted =   myDb.insertData(editText1.getText().toString(),
                        editText2.getText().toString(),
                        editText3.getText().toString(),
                        editText4.getText().toString(),
                        editText5.getText().toString());
              if(isInserted = true)
                  Toast.makeText(getContext(),"Data Inserted",Toast.LENGTH_LONG).show();
              else
                  Toast.makeText(getContext(),"Data Not Inserted",Toast.LENGTH_LONG).show();

            }
        });


        return view;
    }

}
